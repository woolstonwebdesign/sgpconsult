<?php
/*
@package: wwd blankslate
*/

wp_footer(); 
?>
</body>
</html>